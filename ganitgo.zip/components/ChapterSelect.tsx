
import React, { useState, useEffect } from 'react';
import { NCERT_CHAPTERS } from '../constants';
import { Button } from './Button';
import { UserProfile } from '../types';
import { Mascot } from './Mascot';
import { playSound } from '../services/soundService';

interface ChapterSelectProps {
  user: UserProfile;
  onSelectChapter: (chapter: string) => void;
  onBack: () => void;
  onUpdateUser: (updates: Partial<UserProfile>) => void;
}

const DIFFICULTY_MAP = {
  'Easy': 2,
  'Medium': 5,
  'Hard': 8,
  'Expert': 10
};

export const ChapterSelect: React.FC<ChapterSelectProps> = ({ user, onSelectChapter, onBack, onUpdateUser }) => {
  const chapters = NCERT_CHAPTERS[user.grade] || [];
  const [showMascot, setShowMascot] = useState(false);
  
  // Default to user's current level, but mapped to a string category
  const getCategory = (level: number) => {
      if (level <= 3) return 'Easy';
      if (level <= 6) return 'Medium';
      if (level <= 8) return 'Hard';
      return 'Expert';
  };
  
  const [difficulty, setDifficulty] = useState<keyof typeof DIFFICULTY_MAP>(getCategory(user.level));

  useEffect(() => {
    if (!user.tutorialProgress?.chapterSelect) {
      const timer = setTimeout(() => setShowMascot(true), 500);
      return () => clearTimeout(timer);
    }
  }, [user.tutorialProgress]);

  const handleMascotDismiss = () => {
    setShowMascot(false);
    onUpdateUser({
      tutorialProgress: { ...user.tutorialProgress, chapterSelect: true }
    });
  };

  const handleSelect = (chapter: string) => {
      playSound('click');
      // Update user level preference before starting
      onUpdateUser({ level: DIFFICULTY_MAP[difficulty] });
      onSelectChapter(chapter);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 pb-20">
      <div className="flex items-center gap-4 mb-6">
        <Button size="sm" variant="outline" onClick={onBack}>← Back</Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Select Topic</h1>
          <p className="text-gray-500 text-sm">NCERT Grade {user.grade}</p>
        </div>
      </div>

      {/* Difficulty Slider */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-6">
          <label className="block text-gray-700 font-bold mb-4 flex justify-between">
              <span>Challenge Level</span>
              <span className={`text-${difficulty === 'Expert' ? 'red' : difficulty === 'Hard' ? 'orange' : 'green'}-500`}>
                  {difficulty} ({DIFFICULTY_MAP[difficulty]}/10)
              </span>
          </label>
          <input 
            type="range" 
            min="0" 
            max="3" 
            step="1"
            value={Object.keys(DIFFICULTY_MAP).indexOf(difficulty)}
            onChange={(e) => {
                const keys = Object.keys(DIFFICULTY_MAP) as Array<keyof typeof DIFFICULTY_MAP>;
                setDifficulty(keys[parseInt(e.target.value)]);
                playSound('click');
            }}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
          />
          <div className="flex justify-between text-xs text-gray-400 mt-2 font-bold uppercase">
              <span>Easy</span>
              <span>Medium</span>
              <span>Hard</span>
              <span>Expert</span>
          </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Surprise Me Option */}
        <button
          onClick={() => handleSelect('Surprise Me')}
          className="p-6 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all text-left group"
        >
          <div className="text-3xl mb-2 group-hover:animate-bounce">🎲</div>
          <h3 className="font-bold text-xl">Surprise Me</h3>
          <p className="text-indigo-100 text-sm mt-1">Mix of all topics</p>
        </button>

        {/* Chapter List */}
        {chapters.map((chapter, index) => (
          <button
            key={index}
            onClick={() => handleSelect(chapter)}
            className="p-6 rounded-2xl bg-white border border-gray-100 shadow-sm hover:border-indigo-200 hover:shadow-md hover:scale-[1.02] transition-all text-left"
          >
            <div className="flex items-start justify-between mb-2">
              <span className="bg-indigo-50 text-indigo-600 text-xs font-bold px-2 py-1 rounded-md">
                Ch {index + 1}
              </span>
            </div>
            <h3 className="font-bold text-gray-800 text-lg leading-tight">{chapter}</h3>
          </button>
        ))}
      </div>

      {showMascot && (
        <Mascot 
          message="Adjust the slider to set your difficulty! The harder the questions, the more XP you earn!" 
          onDismiss={handleMascotDismiss} 
        />
      )}
    </div>
  );
};
