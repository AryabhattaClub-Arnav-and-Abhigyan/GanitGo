
import React from 'react';
import { Button } from './Button';

interface MascotProps {
  message: string;
  onDismiss: () => void;
  actionLabel?: string;
}

export const Mascot: React.FC<MascotProps> = ({ message, onDismiss, actionLabel = "Got it!" }) => {
  return (
    <div className="fixed bottom-6 left-4 right-4 z-[60] flex items-end justify-center md:justify-start pointer-events-none">
      <div className="flex items-end gap-3 max-w-lg w-full pointer-events-auto animate-float">
        <div className="text-6xl filter drop-shadow-xl cursor-pointer transform hover:scale-110 transition-transform origin-bottom">
          🦁
        </div>
        <div className="bg-white p-5 rounded-2xl rounded-bl-none shadow-2xl border-2 border-indigo-100 flex-1 relative mb-4">
          {/* Speech bubble tail */}
          <div className="absolute -left-3 bottom-0 w-6 h-6 bg-white border-l-2 border-b-2 border-indigo-100 transform rotate-45 translate-x-2 -translate-y-1"></div>
          
          <h4 className="font-bold text-indigo-600 text-xs tracking-wider uppercase mb-1">Lingo says:</h4>
          <p className="text-gray-800 text-base mb-4 leading-relaxed font-medium">
            "{message}"
          </p>
          <div className="flex justify-end">
            <Button size="sm" onClick={onDismiss} className="py-2 px-6 text-sm shadow-md">
              {actionLabel}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
