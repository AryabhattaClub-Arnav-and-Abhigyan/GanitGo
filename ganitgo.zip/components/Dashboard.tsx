import React, { useState, useEffect } from 'react';
import { UserProfile, Riddle } from '../types';
import { Button } from './Button';
import { generateDailyRiddle } from '../services/geminiService';
import { Mascot } from './Mascot';
import { playSound } from '../services/soundService';

interface DashboardProps {
  user: UserProfile;
  onStartGame: () => void;
  onViewLeaderboard: () => void;
  onViewProfile: () => void;
  onViewShop: () => void;
  onLogout: () => void;
  onUpdateUser: (updates: Partial<UserProfile>) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, onStartGame, onViewLeaderboard, onViewProfile, onViewShop, onLogout, onUpdateUser }) => {
  const [dailyRiddle, setDailyRiddle] = useState<Riddle | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [showMascot, setShowMascot] = useState(false);

  useEffect(() => {
    // Load daily riddle
    generateDailyRiddle().then(setDailyRiddle);
    
    // Check tutorial
    if (!user.tutorialProgress?.dashboard) {
      const timer = setTimeout(() => setShowMascot(true), 500);
      return () => clearTimeout(timer);
    }
  }, [user.tutorialProgress]);

  const handleMascotDismiss = () => {
    setShowMascot(false);
    onUpdateUser({
      tutorialProgress: { ...user.tutorialProgress, dashboard: true }
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-4 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-8 pt-4">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl border-2 border-white shadow-md ${user.color}`}>
            {user.avatar}
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800">Hi, {user.name} 👋</h1>
            <p className="text-sm text-gray-500">Grade {user.grade} Student</p>
          </div>
        </div>
        <div className="bg-white px-4 py-2 rounded-full shadow-sm border border-gray-100 flex gap-4">
          <div className="flex items-center gap-1">
            <span>💎</span> <span className="font-bold text-gray-700">{user.coins}</span>
          </div>
          <div className="flex items-center gap-1">
            <span>⚡</span> <span className="font-bold text-gray-700">{user.streak} Days</span>
          </div>
        </div>
      </div>

      {/* Main Action */}
      <div className={`${user.color} rounded-3xl p-8 text-white shadow-xl relative overflow-hidden mb-8 transform hover:scale-[1.01] transition-transform cursor-pointer`} onClick={onStartGame}>
        <div className="relative z-10">
          <span className="inline-block bg-white/20 px-3 py-1 rounded-full text-xs font-bold tracking-wide uppercase mb-3 backdrop-blur-sm">
            Daily Challenge
          </span>
          <h2 className="text-3xl font-extrabold mb-4">Level {user.level} Practice</h2>
          <p className="mb-6 opacity-90 max-w-sm">
            Keep your streak alive! Master Grade {user.grade} math with adaptive problems.
          </p>
          <Button variant="secondary" size="lg" onClick={(e) => { e.stopPropagation(); onStartGame(); playSound('click'); }}>
            Start Learning
          </Button>
        </div>
        {/* Decorative background circle */}
        <div className="absolute -right-10 -bottom-20 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
      </div>

      {/* Pro Version Promo Box */}
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl p-6 shadow-xl mb-8 relative overflow-hidden border border-gray-700">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-yellow-500 mb-1">
              GanitGo PRO 👑
            </h3>
            <p className="text-gray-400 text-sm">
              Unlock unlimited hearts, offline mode, and expert analytics.
            </p>
          </div>
          <button 
            disabled
            className="px-6 py-2 rounded-full bg-gradient-to-r from-yellow-400 to-yellow-600 text-gray-900 font-bold text-sm opacity-90 cursor-not-allowed shadow-[0_0_15px_rgba(234,179,8,0.5)]"
          >
            Coming Soon
          </button>
        </div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-2xl"></div>
      </div>

      {/* Daily Riddle Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
        <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
          🧩 Daily Brain Teaser
        </h3>
        {dailyRiddle ? (
          <div className="space-y-4">
            <p className="text-lg text-gray-700 italic">"{dailyRiddle.riddle}"</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => { setShowAnswer(!showAnswer); playSound('click'); }}>
                {showAnswer ? 'Hide Answer' : 'Show Answer'}
              </Button>
              {!showAnswer && (
                 <button className="text-xs text-gray-400 hover:text-indigo-500" onClick={() => alert(dailyRiddle.hint)}>Need a hint?</button>
              )}
            </div>
            {showAnswer && (
              <div className="bg-green-50 p-3 rounded-lg text-green-800 text-sm font-medium animate-fade-in">
                Answer: {dailyRiddle.answer}
              </div>
            )}
          </div>
        ) : (
           <div className="animate-pulse flex space-x-4">
             <div className="flex-1 space-y-4 py-1">
               <div className="h-4 bg-gray-200 rounded w-3/4"></div>
               <div className="space-y-2">
                 <div className="h-4 bg-gray-200 rounded"></div>
               </div>
             </div>
           </div>
        )}
      </div>

      {/* Grid Menu */}
      <div className="grid grid-cols-3 gap-4">
        <button 
          onClick={() => { onViewShop(); playSound('click'); }}
          className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-left group"
        >
          <div className="w-10 h-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-xl mb-3 group-hover:scale-110 transition-transform">
            🛒
          </div>
          <h3 className="font-bold text-gray-800">Shop</h3>
          <p className="text-xs text-gray-500">Power-ups</p>
        </button>

        <button 
          onClick={() => { onViewLeaderboard(); playSound('click'); }}
          className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-left group"
        >
          <div className="w-10 h-10 rounded-full bg-yellow-100 text-yellow-600 flex items-center justify-center text-xl mb-3 group-hover:scale-110 transition-transform">
            🏆
          </div>
          <h3 className="font-bold text-gray-800">Rank</h3>
          <p className="text-xs text-gray-500">Top Students</p>
        </button>

        <button 
          onClick={() => { onViewProfile(); playSound('click'); }}
          className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-left group"
        >
          <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xl mb-3 group-hover:scale-110 transition-transform">
            👤
          </div>
          <h3 className="font-bold text-gray-800">Profile</h3>
          <p className="text-xs text-gray-500">Stats</p>
        </button>
      </div>

      <div className="mt-8 text-center">
        <button onClick={onLogout} className="text-gray-400 text-sm hover:text-red-500 underline">
          Log out
        </button>
      </div>
      
      {showMascot && (
        <Mascot 
          message={`Welcome back, ${user.name}! This is your HQ. Check your Daily Streak ⚡ and Daily Riddle 🧩 here!`} 
          onDismiss={handleMascotDismiss} 
        />
      )}
    </div>
  );
};