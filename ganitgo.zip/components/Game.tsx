
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { UserProfile, MathProblem } from '../types';
import { generateBatchProblems } from '../services/geminiService';
import { Button } from './Button';
import { Mascot } from './Mascot';
import { playSound } from '../services/soundService';

interface GameProps {
  user: UserProfile;
  selectedChapter: string;
  onUpdateUser: (updates: Partial<UserProfile>) => void;
  onExit: () => void;
}

export const Game: React.FC<GameProps> = ({ user, selectedChapter, onUpdateUser, onExit }) => {
  const [problems, setProblems] = useState<MathProblem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [textAnswer, setTextAnswer] = useState('');
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | 'shielded' | null>(null);
  
  const [sessionStats, setSessionStats] = useState({ correct: 0, xpEarned: 0, coinsEarned: 0 });
  const [streak, setStreak] = useState(0); // Visual session streak
  
  const [hintVisible, setHintVisible] = useState(false);
  const [showMascot, setShowMascot] = useState(false);
  const [gameComplete, setGameComplete] = useState(false);
  
  // Confetti Canvas
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Load inventory safely
  const inventory = user.inventory || { hints: 0, shields: 0, freeze: 0 };

  // This function depends on user.level, so it gets recreated when level changes.
  // This is good for "Next Level" button clicks, but we must prevent it from auto-firing in useEffect.
  const loadBatch = useCallback(async () => {
    setLoading(true);
    setGameComplete(false);
    setSessionStats({ correct: 0, xpEarned: 0, coinsEarned: 0 });
    setCurrentIndex(0);
    setProblems([]);
    
    try {
      // Use user.level which is now possibly set by the difficulty slider in ChapterSelect
      const newProblems = await generateBatchProblems(user.grade, user.level, selectedChapter);
      setProblems(newProblems);
      playSound('levelUp');
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [user.grade, user.level, selectedChapter]);

  useEffect(() => {
    // Trigger only once on mount or if chapter changes. 
    // We intentionally ignore changes to 'loadBatch' (caused by user.level updates) 
    // to prevent reloading the questions mid-game when difficulty drops.
    loadBatch();
    
    // Tutorial Check
    if (!user.tutorialProgress?.game) {
        const timer = setTimeout(() => setShowMascot(true), 1000);
        return () => clearTimeout(timer);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedChapter]);

  // Confetti effect
  const fireConfetti = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: any[] = [];
    for(let i=0; i<100; i++) {
        particles.push({
            x: window.innerWidth / 2,
            y: window.innerHeight / 2,
            vx: (Math.random() - 0.5) * 10,
            vy: (Math.random() - 0.5) * 10,
            color: ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#00ffff', '#ff00ff'][Math.floor(Math.random() * 6)],
            life: 100
        });
    }

    const animate = () => {
        if (!ctx) return;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        let active = false;
        particles.forEach(p => {
            if(p.life > 0) {
                p.x += p.vx;
                p.y += p.vy;
                p.vy += 0.2; // gravity
                p.life--;
                ctx.fillStyle = p.color;
                ctx.fillRect(p.x, p.y, 8, 8);
                active = true;
            }
        });
        if(active) requestAnimationFrame(animate);
    };
    animate();
  };

  const handleMascotDismiss = () => {
      setShowMascot(false);
      onUpdateUser({
          tutorialProgress: { ...user.tutorialProgress, game: true }
      });
  };

  const useHint = () => {
    if (inventory.hints > 0 && !hintVisible) {
      playSound('click');
      onUpdateUser({
        inventory: {
          ...inventory,
          hints: inventory.hints - 1
        }
      });
      setHintVisible(true);
    }
  };

  const handleCheck = () => {
    const currentProblem = problems[currentIndex];
    if (!currentProblem) return;

    let isCorrect = false;
    const userAnswer = currentProblem.options ? selectedOption : textAnswer;

    if (!userAnswer) return;

    const normalizedUser = userAnswer.trim().toLowerCase();
    const normalizedCorrect = currentProblem.correctAnswer.trim().toLowerCase();

    if (normalizedUser === normalizedCorrect) {
      isCorrect = true;
    }

    if (isCorrect) {
      setFeedback('correct');
      playSound('correct');
      fireConfetti();
      
      const isDoubleXp = user.doubleXpTurns > 0;
      const baseXp = 10 * user.level;
      const xpGain = isDoubleXp ? baseXp * 2 : baseXp;
      const coinGain = 5;
      
      const today = new Date().toDateString();

      // Update Local State for Summary
      setSessionStats(prev => ({
        correct: prev.correct + 1,
        xpEarned: prev.xpEarned + xpGain,
        coinsEarned: prev.coinsEarned + coinGain
      }));

      // Update Global User State
      onUpdateUser({
        xp: user.xp + xpGain,
        coins: user.coins + coinGain,
        // No level change here, we wait for end of batch or explicit failure
        lastPlayedDate: today,
        doubleXpTurns: Math.max(0, user.doubleXpTurns - 1)
      });
      setStreak(s => s + 1);
    } else {
      if (inventory.shields > 0) {
        setFeedback('shielded');
        playSound('success'); // Shield sound
        onUpdateUser({
          inventory: {
            ...inventory,
            shields: inventory.shields - 1
          }
        });
      } else {
        setFeedback('incorrect');
        playSound('wrong');
        // Drop level if they get it wrong without shield
        const newLevel = Math.max(1, user.level - 1);
        onUpdateUser({
          level: newLevel
        });
        setStreak(0);
      }
    }
  };

  const handleNextProblem = () => {
    playSound('click');
    setFeedback(null);
    setSelectedOption(null);
    setTextAnswer('');
    setHintVisible(false);

    if (currentIndex < problems.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      playSound('success');
      setGameComplete(true);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center min-h-[60vh]">
        <div className={`w-20 h-20 border-8 border-t-transparent ${user.color.replace('bg-', 'border-')} rounded-full animate-spin mb-6`}></div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Generating Questions...</h2>
        <p className="text-gray-500 font-medium">Creating 10 unique {selectedChapter} problems.</p>
        <p className="text-sm text-gray-400 mt-4 animate-pulse">Adapting difficulty to your level...</p>
      </div>
    );
  }

  if (gameComplete) {
    return (
      <div className="max-w-2xl mx-auto p-8 text-center animate-fade-in relative z-10">
         <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />
        <div className="bg-white rounded-3xl shadow-xl p-8 mb-8 relative overflow-hidden z-10">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 to-purple-600"></div>
          <div className="text-6xl mb-4 animate-bounce">🎉</div>
          <h2 className="text-3xl font-extrabold text-gray-800 mb-2">Level Complete!</h2>
          <p className="text-gray-500 mb-8">Great practice session on {selectedChapter}.</p>

          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="bg-indigo-50 p-4 rounded-2xl transform hover:scale-105 transition-transform">
              <div className="text-2xl font-bold text-indigo-600">{sessionStats.correct}/10</div>
              <div className="text-xs text-indigo-400 uppercase font-bold">Accuracy</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-2xl transform hover:scale-105 transition-transform">
              <div className="text-2xl font-bold text-purple-600">+{sessionStats.xpEarned}</div>
              <div className="text-xs text-purple-400 uppercase font-bold">XP Gained</div>
            </div>
            <div className="bg-yellow-50 p-4 rounded-2xl transform hover:scale-105 transition-transform">
              <div className="text-2xl font-bold text-yellow-600">+{sessionStats.coinsEarned}</div>
              <div className="text-xs text-yellow-400 uppercase font-bold">Coins Found</div>
            </div>
          </div>

          <div className="space-y-3">
            <Button size="lg" className="w-full" onClick={loadBatch}>
              Play Next Level (10 New Qs)
            </Button>
            <Button variant="outline" size="lg" className="w-full" onClick={onExit}>
              Back to Dashboard
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const currentProblem = problems[currentIndex];
  if (!currentProblem) return <div className="p-8 text-center text-red-500">Error loading problems. <Button onClick={onExit}>Go Back</Button></div>;

  return (
    <div className="max-w-2xl mx-auto p-4 pb-24 relative">
       {/* Confetti Overlay */}
      <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-50" style={{display: feedback === 'correct' ? 'block' : 'none'}} />

      <div className="flex justify-between items-center mb-6">
        <Button variant="outline" size="sm" onClick={onExit}>Exit</Button>
        <div className="flex items-center gap-2">
           {user.doubleXpTurns > 0 && (
             <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-bold animate-pulse">
               2x XP
             </span>
           )}
           <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs font-bold">
             {currentIndex + 1} / {problems.length}
           </span>
           <span className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full text-xs font-bold">
             Lvl {user.level}
           </span>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-xl p-6 md:p-8 mb-6 relative overflow-hidden transition-all duration-300">
        {/* Progress Bar */}
        <div className="absolute top-0 left-0 h-1 bg-gray-100 w-full">
            <div 
                className="h-full bg-indigo-500 transition-all duration-500" 
                style={{ width: `${((currentIndex) / problems.length) * 100}%` }}
            ></div>
        </div>

        {/* Shield Indicator */}
        {inventory.shields > 0 && !feedback && (
          <div className="absolute top-4 right-4 bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 animate-pulse">
            🛡️ Shield On
          </div>
        )}

        <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4 gap-2 mt-2">
          <div>
            <span className="text-xs font-bold tracking-wider text-gray-400 uppercase block">{currentProblem.topic}</span>
            <span className="text-xs text-indigo-400">{selectedChapter}</span>
          </div>
          <span className="text-xs font-bold text-indigo-500 bg-indigo-50 px-2 py-1 rounded">Difficulty: {currentProblem.difficulty}/10</span>
        </div>
        
        <h2 className="text-xl md:text-2xl font-bold text-gray-800 mb-6 leading-relaxed">
          {currentProblem.question}
        </h2>

        {/* SVG/Image Section */}
        {currentProblem.svg && (
          <div className="mb-8 flex justify-center bg-gray-50 rounded-xl p-4 border border-gray-100">
             <div 
               className="w-full max-w-sm h-auto"
               dangerouslySetInnerHTML={{ __html: currentProblem.svg }} 
             />
          </div>
        )}

        {/* Hint Section */}
        {hintVisible && (
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6 rounded-r-lg animate-fade-in">
             <p className="text-yellow-800 text-sm font-medium">💡 Hint: {currentProblem.hint || "Read the question carefully!"}</p>
          </div>
        )}

        {currentProblem.options && currentProblem.options.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentProblem.options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => {
                   if (!feedback) {
                       playSound('click');
                       setSelectedOption(option);
                   }
                }}
                className={`p-4 rounded-xl border-2 text-left transition-all duration-200 ${
                  selectedOption === option 
                    ? `border-indigo-500 bg-indigo-50 text-indigo-900 ring-2 ring-indigo-200 transform scale-[1.02]` 
                    : 'border-gray-200 hover:border-indigo-200 text-gray-700 hover:bg-gray-50'
                } ${feedback ? 'cursor-default opacity-80' : ''}`}
                disabled={!!feedback}
              >
                <div className="flex items-center">
                  <span className={`w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center mr-3 text-sm font-bold text-gray-500 ${selectedOption === option ? 'bg-indigo-500 text-white border-indigo-500' : 'bg-white'}`}>
                    {String.fromCharCode(65 + idx)}
                  </span>
                  {option}
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div>
            <input 
              type="text" 
              value={textAnswer}
              onChange={(e) => setTextAnswer(e.target.value)}
              placeholder="Type your answer here..."
              className="w-full p-4 text-lg border-2 border-gray-300 rounded-xl focus:border-indigo-500 focus:ring-4 focus:ring-indigo-100 outline-none"
              disabled={!!feedback}
            />
          </div>
        )}
      </div>

      {feedback && (
        <div className={`rounded-2xl p-6 mb-6 shadow-lg transform transition-all duration-500 ${
          feedback === 'correct' ? 'bg-green-50 border-2 border-green-200 animate-[bounce_1s]' : 
          feedback === 'shielded' ? 'bg-blue-50 border-2 border-blue-200' : 'bg-red-50 border-2 border-red-200 animate-[shake_0.5s]'
        }`}>
          <div className="flex items-start gap-4">
            <div className={`text-4xl`}>
              {feedback === 'correct' ? '🎉' : feedback === 'shielded' ? '🛡️' : '🤯'}
            </div>
            <div className="flex-1">
              <h3 className={`font-bold text-lg mb-2 ${
                feedback === 'correct' ? 'text-green-800' : feedback === 'shielded' ? 'text-blue-800' : 'text-red-800'
              }`}>
                {feedback === 'correct' ? 'Correct!' : feedback === 'shielded' ? 'Shield Protected!' : 'Incorrect'}
              </h3>
              
              {feedback === 'shielded' ? (
                 <p className="text-blue-900 text-sm">Your Shield absorbed the mistake. Keep going!</p>
              ) : (
                <div className="space-y-3">
                  {feedback === 'incorrect' && (
                    <div className="bg-white/70 p-3 rounded-lg border border-red-100 shadow-sm">
                        <span className="block text-xs font-bold text-red-500 uppercase tracking-wider mb-1">Correct Answer</span>
                        <p className="font-bold text-gray-900 text-lg">{currentProblem.correctAnswer}</p>
                    </div>
                  )}
                  
                  <div className={`p-3 rounded-lg ${feedback === 'correct' ? 'bg-green-100 text-green-900' : 'bg-red-100 text-red-900'}`}>
                    <span className="block text-xs font-bold opacity-70 uppercase tracking-wider mb-1">Why is this correct?</span>
                    <p className="text-sm leading-relaxed">{currentProblem.explanation}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-100 shadow-[0_-5px_15px_rgba(0,0,0,0.05)] md:static md:bg-transparent md:border-0 md:shadow-none flex flex-col md:flex-row gap-4 justify-center items-center z-40">
        {!feedback ? (
          <div className="flex w-full md:w-auto gap-3">
             <Button 
               className="flex-1 md:flex-none"
               variant="secondary"
               onClick={useHint}
               disabled={hintVisible || inventory.hints <= 0}
               title={inventory.hints > 0 ? `Use Hint (${inventory.hints} left)` : "No hints left"}
             >
               💡 Hint {inventory.hints > 0 && `(${inventory.hints})`}
             </Button>
             <Button 
               className="flex-[2] md:w-64" 
               size="lg" 
               onClick={handleCheck}
               disabled={(!selectedOption && !textAnswer)}
             >
               Check Answer
             </Button>
          </div>
        ) : (
          <Button 
            className="w-full md:max-w-xs md:mx-auto" 
            size="lg" 
            variant={feedback === 'correct' ? 'success' : feedback === 'shielded' ? 'primary' : 'primary'}
            onClick={handleNextProblem}
          >
            {currentIndex < problems.length - 1 ? "Next Problem →" : "Finish Level →"}
          </Button>
        )}
      </div>

      {showMascot && (
          <Mascot 
            message="You are about to start a batch of 10 questions! Difficulty will increase as you go! 🚀" 
            onDismiss={handleMascotDismiss} 
          />
      )}
    </div>
  );
};
