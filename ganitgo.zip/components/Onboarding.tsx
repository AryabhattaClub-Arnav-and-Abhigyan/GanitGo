import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Button } from './Button';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
  existingUser?: UserProfile | null;
}

const AVATARS = ['🦁', '🦊', '🐼', '🐨', '🐯', '🐙', '🦄', '🚀', '🧠', '🦉'];
const COLORS = [
  { name: 'Blue', class: 'bg-blue-500' },
  { name: 'Purple', class: 'bg-purple-500' },
  { name: 'Green', class: 'bg-green-500' },
  { name: 'Orange', class: 'bg-orange-500' },
  { name: 'Pink', class: 'bg-pink-500' },
];

type ViewState = 'landing' | 'login' | 'signup';

export const Onboarding: React.FC<OnboardingProps> = ({ onComplete, existingUser }) => {
  const [view, setView] = useState<ViewState>('landing');
  
  // Signup State
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [grade, setGrade] = useState(6);
  const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0]);
  const [selectedColor, setSelectedColor] = useState(COLORS[0].class);
  
  // Login State
  const [loginPassword, setLoginPassword] = useState('');
  
  const [error, setError] = useState('');

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError("Name is too short");
      return;
    }
    if (password.length < 4) {
      setError("Password must be at least 4 characters");
      return;
    }

    const newProfile: UserProfile = {
      name,
      password,
      grade,
      avatar: selectedAvatar,
      color: selectedColor,
      xp: 0,
      level: 1,
      coins: 100, // Starting bonus
      streak: 0,
      lastPlayedDate: null,
      inventory: { hints: 1, shields: 0, freeze: 0 },
      doubleXpTurns: 0,
      tutorialProgress: {
        dashboard: false,
        shop: false,
        game: false,
        leaderboard: false,
        chapterSelect: false
      }
    };
    onComplete(newProfile);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (existingUser && existingUser.password === loginPassword) {
      onComplete(existingUser);
    } else {
      setError("Incorrect password");
    }
  };

  const clearError = () => setError('');

  // RENDER LANDING
  if (view === 'landing') {
    return (
       <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-indigo-500 to-purple-600">
         <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden p-8 text-center animate-float">
            <div className="text-6xl mb-6">🧮</div>
            <h1 className="text-4xl font-extrabold text-gray-800 mb-2">GanitGo</h1>
            <p className="text-gray-500 mb-8">Master NCERT Math with daily puzzles, rewards, and battles.</p>

            {existingUser ? (
                <div className="bg-indigo-50 rounded-2xl p-6 mb-6">
                    <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center text-3xl mb-3 ${existingUser.color} text-white shadow-md`}>
                        {existingUser.avatar}
                    </div>
                    <h3 className="font-bold text-gray-800 text-lg">Welcome back, {existingUser.name}!</h3>
                    <p className="text-sm text-gray-500 mb-4">Grade {existingUser.grade}</p>
                    <Button className="w-full" onClick={() => setView('login')}>
                        Continue Learning
                    </Button>
                    <button 
                        onClick={() => setView('signup')}
                        className="mt-4 text-xs text-gray-400 hover:text-indigo-500 font-bold"
                    >
                        Not {existingUser.name}? Create New Account
                    </button>
                </div>
            ) : (
                <div className="space-y-4">
                    <Button size="lg" className="w-full" onClick={() => setView('signup')}>
                        Create Free Account
                    </Button>
                    <Button variant="outline" className="w-full" onClick={() => {
                        alert("No account found on this device. Please create a new one!");
                        setView('signup');
                    }}>
                        I have an account
                    </Button>
                </div>
            )}
         </div>
       </div>
    );
  }

  // RENDER LOGIN
  if (view === 'login' && existingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden p-8">
           <button onClick={() => setView('landing')} className="text-gray-400 hover:text-gray-600 mb-4 font-bold">← Back</button>
           <div className="text-center mb-6">
             <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center text-3xl mb-3 ${existingUser.color} text-white`}>
                {existingUser.avatar}
             </div>
             <h2 className="text-2xl font-bold text-gray-800">Enter Password</h2>
             <p className="text-gray-500 text-sm">To access {existingUser.name}'s account</p>
           </div>
           
           <form onSubmit={handleLogin} className="space-y-6">
             <input
                type="password"
                value={loginPassword}
                onChange={(e) => { setLoginPassword(e.target.value); clearError(); }}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                placeholder="Password"
                autoFocus
             />
             {error && <p className="text-red-500 text-sm text-center font-bold">{error}</p>}
             <Button type="submit" size="lg" className="w-full">Let's Go!</Button>
           </form>
        </div>
      </div>
    );
  }

  // RENDER SIGNUP
  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden p-8">
        <button onClick={() => setView('landing')} className="text-gray-400 hover:text-gray-600 mb-4 font-bold">← Back</button>
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Create Profile</h2>
          <p className="text-gray-500">Join the GanitGo squad!</p>
        </div>

        <form onSubmit={handleSignup} className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => { setName(e.target.value); clearError(); }}
              className="w-full px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-indigo-500 outline-none transition-colors"
              placeholder="Your Name"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Secret Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => { setPassword(e.target.value); clearError(); }}
              className="w-full px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-indigo-500 outline-none transition-colors"
              placeholder="Keep it safe"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Grade</label>
            <div className="grid grid-cols-4 gap-2">
              {[6, 7, 8, 9, 10, 11, 12].map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGrade(g)}
                  className={`py-1 rounded-lg font-bold border-2 text-sm transition-all ${
                    grade === g 
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700' 
                      : 'border-gray-200 text-gray-500 hover:border-indigo-300'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-1">Avatar</label>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {AVATARS.map((av) => (
                <button
                  key={av}
                  type="button"
                  onClick={() => setSelectedAvatar(av)}
                  className={`text-xl min-w-[45px] h-[45px] rounded-full flex items-center justify-center transition-transform hover:scale-110 ${
                    selectedAvatar === av ? 'bg-indigo-100 ring-2 ring-indigo-500' : 'bg-gray-50'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>

          <div>
             <label className="block text-sm font-bold text-gray-700 mb-1">Theme</label>
             <div className="flex gap-3 justify-center">
               {COLORS.map((c) => (
                 <button
                   key={c.name}
                   type="button"
                   onClick={() => setSelectedColor(c.class)}
                   className={`w-8 h-8 rounded-full transition-transform hover:scale-110 ${c.class} ${
                     selectedColor === c.class ? 'ring-2 ring-offset-2 ring-gray-400 scale-110' : ''
                   }`}
                 />
               ))}
             </div>
          </div>

          {error && <p className="text-red-500 text-sm text-center font-bold">{error}</p>}

          <Button type="submit" size="lg" className="w-full mt-2">
            Create Account
          </Button>
        </form>
      </div>
    </div>
  );
};