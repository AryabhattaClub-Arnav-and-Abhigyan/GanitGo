import React, { useState, useEffect } from 'react';
import { UserProfile, Inventory } from '../types';
import { Button } from './Button';
import { Mascot } from './Mascot';

interface ShopProps {
  user: UserProfile;
  onUpdateUser: (updates: Partial<UserProfile>) => void;
  onBack: () => void;
}

const ITEMS = [
  {
    id: 'hint',
    name: 'Hint Scroll',
    emoji: '📜',
    description: 'Stuck? Reveal a helpful hint during a puzzle.',
    price: 50,
    field: 'hints' as keyof Inventory
  },
  {
    id: 'shield',
    name: 'Combo Shield',
    emoji: '🛡️',
    description: 'Prevents your combo and difficulty level from dropping on a wrong answer.',
    price: 150,
    field: 'shields' as keyof Inventory
  },
  {
    id: 'freeze',
    name: 'Streak Freeze',
    emoji: '❄️',
    description: 'Missed a day? This automatically protects your daily streak.',
    price: 300,
    field: 'freeze' as keyof Inventory
  },
  {
    id: 'doubleXp',
    name: 'Double XP (10 Qs)',
    emoji: '🧪',
    description: 'Earn 2x XP for the next 10 questions you answer correctly.',
    price: 200,
    special: true
  }
];

export const Shop: React.FC<ShopProps> = ({ user, onUpdateUser, onBack }) => {
  const [showMascot, setShowMascot] = useState(false);

  useEffect(() => {
    if (!user.tutorialProgress?.shop) {
      const timer = setTimeout(() => setShowMascot(true), 500);
      return () => clearTimeout(timer);
    }
  }, [user.tutorialProgress]);

  const handleMascotDismiss = () => {
    setShowMascot(false);
    onUpdateUser({
      tutorialProgress: { ...user.tutorialProgress, shop: true }
    });
  };

  const handleBuy = (item: typeof ITEMS[0]) => {
    if (user.coins < item.price) return;

    const newCoins = user.coins - item.price;
    
    if (item.special && item.id === 'doubleXp') {
      onUpdateUser({
        coins: newCoins,
        doubleXpTurns: (user.doubleXpTurns || 0) + 10
      });
    } else if (item.field) {
      onUpdateUser({
        coins: newCoins,
        inventory: {
          ...user.inventory,
          [item.field]: (user.inventory[item.field] || 0) + 1
        }
      });
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 pb-20">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button size="sm" variant="outline" onClick={onBack}>← Back</Button>
          <h1 className="text-2xl font-bold text-gray-800">Item Shop</h1>
        </div>
        <div className="bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full font-bold flex items-center gap-2">
          💎 {user.coins}
        </div>
      </div>

      <div className="grid gap-4">
        {ITEMS.map((item) => {
          const canAfford = user.coins >= item.price;
          // Determine quantity
          let quantity = 0;
          if (item.special && item.id === 'doubleXp') {
             quantity = user.doubleXpTurns;
          } else if (item.field) {
             quantity = user.inventory[item.field] || 0;
          }

          return (
            <div key={item.id} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-gray-50 flex items-center justify-center text-4xl shadow-inner">
                {item.emoji}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-gray-800 flex items-center gap-2">
                  {item.name}
                  {quantity > 0 && (
                    <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full">
                      Owned: {quantity}
                    </span>
                  )}
                </h3>
                <p className="text-sm text-gray-500 leading-tight mt-1">{item.description}</p>
              </div>
              <Button 
                onClick={() => handleBuy(item)}
                disabled={!canAfford}
                variant={canAfford ? 'primary' : 'outline'}
                className={!canAfford ? 'opacity-50' : ''}
              >
                <div className="flex flex-col items-center">
                  <span className="text-sm">Buy</span>
                  <span className="text-xs font-bold">💎 {item.price}</span>
                </div>
              </Button>
            </div>
          );
        })}
      </div>

      {showMascot && (
        <Mascot 
          message="Spend your Gems 💎 here! Hints 📜 help you solve puzzles, and Shields 🛡️ protect your combo streak!" 
          onDismiss={handleMascotDismiss} 
        />
      )}
    </div>
  );
};