import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { Button } from './Button';
import { Mascot } from './Mascot';

interface LeaderboardProps {
  user: UserProfile;
  onBack: () => void;
  onUpdateUser: (updates: Partial<UserProfile>) => void;
}

const MOCK_USERS = [
  { name: 'Arya S.', xp: 4520, avatar: '🦊', color: 'bg-orange-500' },
  { name: 'Rohan K.', xp: 3890, avatar: '🐯', color: 'bg-blue-500' },
  { name: 'Priya M.', xp: 3450, avatar: '🦄', color: 'bg-pink-500' },
  { name: 'Vihaan', xp: 3100, avatar: '🚀', color: 'bg-purple-500' },
];

export const Leaderboard: React.FC<LeaderboardProps> = ({ user, onBack, onUpdateUser }) => {
  const [showMascot, setShowMascot] = useState(false);

  useEffect(() => {
    if (!user.tutorialProgress?.leaderboard) {
      const timer = setTimeout(() => setShowMascot(true), 500);
      return () => clearTimeout(timer);
    }
  }, [user.tutorialProgress]);

  const handleMascotDismiss = () => {
    setShowMascot(false);
    onUpdateUser({
      tutorialProgress: { ...user.tutorialProgress, leaderboard: true }
    });
  };

  // Combine mock users with current user and sort
  const allUsers = [
    ...MOCK_USERS.map(u => ({ ...u, isCurrentUser: false })), 
    { name: user.name, xp: user.xp, avatar: user.avatar, color: user.color, isCurrentUser: true }
  ].sort((a, b) => b.xp - a.xp);

  return (
    <div className="max-w-2xl mx-auto p-4 pb-20">
      <div className="flex items-center gap-4 mb-8">
        <Button size="sm" variant="outline" onClick={onBack}>← Back</Button>
        <h1 className="text-2xl font-bold text-gray-800">Leaderboard</h1>
      </div>

      <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl p-6 text-white shadow-lg mb-8">
        <div className="text-center">
          <p className="text-indigo-100 font-medium mb-1">Your Rank</p>
          <h2 className="text-4xl font-extrabold">#{allUsers.findIndex(u => u.isCurrentUser) + 1}</h2>
          <p className="text-sm text-indigo-200 mt-2">Top 10% of Grade {user.grade}</p>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        {allUsers.map((u, index) => (
          <div 
            key={index} 
            className={`flex items-center p-4 border-b border-gray-50 last:border-0 ${u.isCurrentUser ? 'bg-indigo-50' : ''}`}
          >
            <div className="w-8 text-center font-bold text-gray-400 mr-4">
              {index + 1}
            </div>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xl text-white mr-4 ${u.color}`}>
              {u.avatar}
            </div>
            <div className="flex-1">
              <h4 className={`font-bold ${u.isCurrentUser ? 'text-indigo-900' : 'text-gray-800'}`}>
                {u.name} {u.isCurrentUser && '(You)'}
              </h4>
              <p className="text-xs text-gray-500">Grade {user.grade}</p>
            </div>
            <div className="font-bold text-indigo-600">
              {u.xp.toLocaleString()} XP
            </div>
          </div>
        ))}
      </div>

      {showMascot && (
        <Mascot 
          message="Compete with students across the country! Earn XP to climb the ranks!" 
          onDismiss={handleMascotDismiss} 
        />
      )}
    </div>
  );
};