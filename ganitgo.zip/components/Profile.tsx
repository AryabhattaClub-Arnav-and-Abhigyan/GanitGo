import React from 'react';
import { UserProfile } from '../types';
import { Button } from './Button';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, Tooltip } from 'recharts';

interface ProfileProps {
  user: UserProfile;
  onBack: () => void;
  onUpdateUser: (updates: Partial<UserProfile>) => void;
}

export const Profile: React.FC<ProfileProps> = ({ user, onBack, onUpdateUser }) => {
  const statsData = [
    { name: 'Correct', value: user.xp / 10 },
    { name: 'Pending', value: 100 }, // Mock data for chart visuals
  ];
  const COLORS = ['#6366f1', '#e5e7eb'];

  const weeklyActivity = [
    { day: 'Mon', xp: 120 },
    { day: 'Tue', xp: 200 },
    { day: 'Wed', xp: 150 },
    { day: 'Thu', xp: 280 },
    { day: 'Fri', xp: user.xp > 0 ? user.xp % 300 + 50 : 0 },
    { day: 'Sat', xp: 0 },
    { day: 'Sun', xp: 0 },
  ];

  const inventory = user.inventory || { hints: 0, shields: 0, freeze: 0 };

  return (
    <div className="max-w-2xl mx-auto p-4 pb-20">
      <div className="flex items-center gap-4 mb-6">
        <Button size="sm" variant="outline" onClick={onBack}>← Back</Button>
        <h1 className="text-2xl font-bold text-gray-800">My Profile</h1>
      </div>

      <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 mb-6 text-center">
        <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center text-5xl mb-4 ${user.color} text-white shadow-lg`}>
          {user.avatar}
        </div>
        <h2 className="text-2xl font-bold text-gray-800">{user.name}</h2>
        <p className="text-gray-500 mb-6">Class {user.grade} • Level {user.level} Mathlete</p>
        
        <div className="grid grid-cols-3 gap-4 border-t border-gray-100 pt-6">
          <div>
            <div className="text-2xl font-bold text-indigo-600">{user.coins}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">Coins</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-indigo-600">{user.xp}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">XP Earned</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-indigo-600">{user.streak}</div>
            <div className="text-xs text-gray-400 uppercase tracking-wide">Day Streak</div>
          </div>
        </div>
      </div>

      {/* Inventory Section */}
      <div className="bg-indigo-50 rounded-2xl p-6 mb-6">
        <h3 className="font-bold text-indigo-900 mb-4">My Inventory 🎒</h3>
        <div className="flex gap-4 overflow-x-auto pb-2">
            <div className="min-w-[100px] bg-white p-3 rounded-xl border border-indigo-100 text-center">
                <div className="text-2xl mb-1">📜</div>
                <div className="text-xs font-bold mb-1">Hints</div>
                <div className="text-lg text-indigo-600 font-bold">{inventory.hints}</div>
            </div>
            <div className="min-w-[100px] bg-white p-3 rounded-xl border border-indigo-100 text-center">
                <div className="text-2xl mb-1">🛡️</div>
                <div className="text-xs font-bold mb-1">Shields</div>
                <div className="text-lg text-indigo-600 font-bold">{inventory.shields}</div>
            </div>
            <div className="min-w-[100px] bg-white p-3 rounded-xl border border-indigo-100 text-center">
                <div className="text-2xl mb-1">❄️</div>
                <div className="text-xs font-bold mb-1">Freezes</div>
                <div className="text-lg text-indigo-600 font-bold">{inventory.freeze}</div>
            </div>
             <div className="min-w-[100px] bg-white p-3 rounded-xl border border-indigo-100 text-center">
                <div className="text-2xl mb-1">🧪</div>
                <div className="text-xs font-bold mb-1">2x XP</div>
                <div className="text-lg text-indigo-600 font-bold">{user.doubleXpTurns}</div>
            </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-700 mb-4">Total Progress</h3>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statsData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={60}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-700 mb-4">Activity</h3>
          <div className="h-48 w-full">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={weeklyActivity}>
                 <XAxis dataKey="day" hide />
                 <Tooltip cursor={{fill: 'transparent'}} />
                 <Bar dataKey="xp" fill="#6366f1" radius={[4, 4, 0, 0]} />
               </BarChart>
             </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};