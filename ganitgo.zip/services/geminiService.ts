
import { GoogleGenAI, Type } from "@google/genai";
import { MathProblem, Riddle, BatchResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = "gemini-2.5-flash";

export const generateBatchProblems = async (grade: number, difficulty: number, chapter?: string): Promise<MathProblem[]> => {
  const topicContext = chapter && chapter !== 'Surprise Me' 
    ? `Focus strictly on the NCERT chapter: "${chapter}".` 
    : `Choose a variety of topics from the Grade ${grade} NCERT syllabus.`;

  // Explicitly ask for exactly 10 questions
  const prompt = `
    Generate a single batch of exactly 10 unique math problems for a Grade ${grade} student.
    ${topicContext}
    
    Difficulty Requirements:
    - Start the batch at difficulty Level ${Math.max(1, difficulty - 1)}.
    - Gradually increase the difficulty so the last few questions are Level ${Math.min(10, difficulty + 2)}.
    - Make the final question a challenging "Boss Level" question.
    
    Content Requirements:
    1. Output exactly 10 problems in the array.
    2. Ensure questions are distinct and not repetitive.
    3. If a problem involves geometry, graphs, or shapes, provide a simple, clean SVG string in the "svg" field (viewBox "0 0 300 200").
    4. Provide 4 multiple choice options for each problem.
    5. Be precise with mathematical calculations.
    
    Output strictly in JSON format with a root key "problems" containing the array of 10 items.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            problems: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: { 
                    type: Type.ARRAY, 
                    items: { type: Type.STRING },
                    description: "Array of 4 possible answers."
                  },
                  correctAnswer: { type: Type.STRING },
                  explanation: { type: Type.STRING, description: "Short explanation of the solution." },
                  hint: { type: Type.STRING, description: "A helpful hint." },
                  topic: { type: Type.STRING },
                  difficulty: { type: Type.NUMBER },
                  svg: { type: Type.STRING, description: "Optional raw SVG code string." }
                },
                required: ["question", "correctAnswer", "explanation", "topic", "difficulty"]
              }
            }
          }
        }
      }
    });

    if (response.text) {
      const data = JSON.parse(response.text) as BatchResponse;
      // Ensure we limit to 10 just in case, though the prompt should handle it
      return (data.problems || []).slice(0, 10);
    }
    throw new Error("No text response from Gemini");
  } catch (error) {
    console.error("Error generating math problems:", error);
    // Fallback batch if API fails
    return Array(10).fill(null).map((_, i) => ({
      question: `Practice Question ${i + 1}: What is ${i + 2} * ${i + 2}?`,
      options: [`${(i + 2) * (i + 2)}`, `${(i + 2) * (i + 2) - 1}`, `${(i + 2) * (i + 2) + 1}`, "100"],
      correctAnswer: `${(i + 2) * (i + 2)}`,
      explanation: "Square the number.",
      hint: "Multiply the number by itself.",
      topic: "Arithmetic",
      difficulty: 1
    }));
  }
};

export const generateDailyRiddle = async (): Promise<Riddle> => {
  const prompt = "Generate a fun, math-related riddle for middle/high school students. Output JSON.";
  
  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riddle: { type: Type.STRING },
            answer: { type: Type.STRING },
            hint: { type: Type.STRING }
          },
          required: ["riddle", "answer", "hint"]
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as Riddle;
    }
    throw new Error("No response");
  } catch (error) {
    return {
      riddle: "I add five to nine, and get two. The answer is correct, but how?",
      answer: "When it is time. 9am + 5 hours = 2pm.",
      hint: "Think about a clock."
    };
  }
};
