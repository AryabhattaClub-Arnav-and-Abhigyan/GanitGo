
import React, { useState, useEffect } from 'react';
import { UserProfile, Screen, TutorialProgress } from './types';
import { Onboarding } from './components/Onboarding';
import { Dashboard } from './components/Dashboard';
import { Game } from './components/Game';
import { Leaderboard } from './components/Leaderboard';
import { Profile } from './components/Profile';
import { Shop } from './components/Shop';
import { ChapterSelect } from './components/ChapterSelect';

const STORAGE_KEY = 'mathalingo_user';

const DEFAULT_TUTORIAL_PROGRESS: TutorialProgress = {
  dashboard: false,
  shop: false,
  game: false,
  leaderboard: false,
  chapterSelect: false
};

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [currentScreen, setCurrentScreen] = useState<Screen>('onboarding');
  const [existingUser, setExistingUser] = useState<UserProfile | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<string>('Surprise Me');

  // Check for existing user on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsedUser = JSON.parse(saved);
        setExistingUser(parsedUser);
      } catch (e) {
        console.error("Failed to parse user data");
      }
    }
  }, []);

  // Save user changes
  const handleUpdateUser = (updates: Partial<UserProfile>) => {
    if (!user) return;
    const updatedUser = { ...user, ...updates };
    setUser(updatedUser);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUser));
  };

  const handleLoginOrRegister = (profile: UserProfile) => {
    // Check Daily Streak Logic upon Login
    const today = new Date().toDateString();
    let newStreak = profile.streak;
    let newFreeze = profile.inventory ? profile.inventory.freeze : 0;
    
    // Only check streak if they have played before
    if (profile.lastPlayedDate) {
        const lastPlayed = new Date(profile.lastPlayedDate);
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        
        // Compare dates (ignoring time)
        if (profile.lastPlayedDate !== today) {
            // Check if played yesterday
            if (lastPlayed.toDateString() === yesterday.toDateString()) {
                // Good, streak maintained.
            } else {
                // Missed a day
                if (newFreeze > 0) {
                    newFreeze--;
                    alert("❄️ Streak Freeze Used! Your streak has been saved.");
                } else {
                    newStreak = 0;
                    // Only alert if they actually lost a streak > 0
                    if (profile.streak > 0) alert("Oh no! You missed a day. Streak reset to 0.");
                }
            }
        }
    }

    // Ensure structure is up to date (migration)
    const normalizedProfile: UserProfile = {
       ...profile,
       streak: newStreak,
       inventory: {
         hints: profile.inventory?.hints || 0,
         shields: profile.inventory?.shields || 0,
         freeze: newFreeze
       },
       doubleXpTurns: profile.doubleXpTurns || 0,
       tutorialProgress: profile.tutorialProgress || DEFAULT_TUTORIAL_PROGRESS
    };

    setUser(normalizedProfile);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalizedProfile));
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    // We do NOT clear localStorage, just the session
    setUser(null);
    setCurrentScreen('onboarding');
    
    // Reload existing user from storage to show "Welcome back" on next render
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setExistingUser(JSON.parse(saved));
    }
  };

  const handleChapterSelect = (chapter: string) => {
    setSelectedChapter(chapter);
    setCurrentScreen('practice');
  };

  // Render logic
  if (!user) {
    return <Onboarding onComplete={handleLoginOrRegister} existingUser={existingUser} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      {currentScreen === 'dashboard' && (
        <Dashboard 
          user={user} 
          onStartGame={() => setCurrentScreen('chapterSelect')}
          onViewLeaderboard={() => setCurrentScreen('leaderboard')}
          onViewProfile={() => setCurrentScreen('profile')}
          onViewShop={() => setCurrentScreen('shop')}
          onLogout={handleLogout}
          onUpdateUser={handleUpdateUser}
        />
      )}

      {currentScreen === 'chapterSelect' && (
        <ChapterSelect 
          user={user}
          onSelectChapter={handleChapterSelect}
          onBack={() => setCurrentScreen('dashboard')}
          onUpdateUser={handleUpdateUser}
        />
      )}

      {currentScreen === 'practice' && (
        <Game 
          user={user} 
          selectedChapter={selectedChapter}
          onUpdateUser={handleUpdateUser} 
          onExit={() => setCurrentScreen('chapterSelect')} 
        />
      )}

      {currentScreen === 'leaderboard' && (
        <Leaderboard 
          user={user} 
          onBack={() => setCurrentScreen('dashboard')}
          onUpdateUser={handleUpdateUser} 
        />
      )}

      {currentScreen === 'profile' && (
        <Profile 
          user={user} 
          onUpdateUser={handleUpdateUser} 
          onBack={() => setCurrentScreen('dashboard')} 
        />
      )}

      {currentScreen === 'shop' && (
        <Shop 
          user={user} 
          onUpdateUser={handleUpdateUser} 
          onBack={() => setCurrentScreen('dashboard')} 
        />
      )}
    </div>
  );
};

export default App;
