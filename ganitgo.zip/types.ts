
export interface Inventory {
  hints: number;
  shields: number; // Protects combo/level on wrong answer
  freeze: number; // Protects daily streak
}

export interface TutorialProgress {
  dashboard: boolean;
  shop: boolean;
  game: boolean;
  leaderboard: boolean;
  chapterSelect: boolean;
}

export interface UserProfile {
  name: string;
  password?: string; // Simple password for local auth
  grade: number; // 6 to 12
  avatar: string; // Emoji
  color: string; // Tailwind color class
  xp: number;
  level: number; // 1 to 10 (Current Difficulty Level)
  coins: number;
  streak: number;
  lastPlayedDate: string | null;
  inventory: Inventory;
  doubleXpTurns: number;
  tutorialProgress: TutorialProgress;
}

export enum Difficulty {
  Beginner = 1,
  Easy = 2,
  Intermediate = 4,
  Advanced = 7,
  Expert = 9,
  Master = 10,
}

export interface MathProblem {
  question: string;
  options?: string[]; // If multiple choice
  correctAnswer: string;
  explanation: string;
  hint?: string;
  topic: string;
  difficulty: number;
  svg?: string; // Optional SVG code for geometry/figures
}

export interface BatchResponse {
  problems: MathProblem[];
}

export interface Riddle {
  riddle: string;
  answer: string;
  hint: string;
}

export type Screen = 'onboarding' | 'dashboard' | 'chapterSelect' | 'practice' | 'leaderboard' | 'profile' | 'shop';
